//
//  main.m
//  RKApplicationTests
//
//  Created by Blake Watters on 2/8/12.
//  Copyright (c) 2009-2012 RestKit. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RKATAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RKATAppDelegate class]));
    }
}
