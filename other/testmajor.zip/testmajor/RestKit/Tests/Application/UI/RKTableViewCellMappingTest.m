//
//  RKTableViewCellMappingTest.m
//  RestKit
//
//  Created by Blake Watters on 8/4/11.
//  Copyright (c) 2009-2012 RestKit. All rights reserved.
//

#import "RKTestEnvironment.h"
#import "RKTableViewCellMapping.h"

@interface RKTableViewCellMappingTest : RKTestCase

@end

@implementation RKTableViewCellMappingTest

- (void)testCallTheDesignatedInitializerOnUITableViewCell
{

}

- (void)testDequeueReusableCells
{

}

- (void)testSetTheAccessoryType
{

}

- (void)testSetTheCellStyle
{

}

@end
