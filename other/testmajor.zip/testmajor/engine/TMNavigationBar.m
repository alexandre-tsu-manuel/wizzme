//
//  SFCustomNavigationBar.m
//  CustomNavigationBar
//
//  Created by Krzysztof Zabłocki on 2/21/12.
//  Copyright (c) 2012 Krzysztof Zabłocki. All rights reserved.
//

#import "TMNavigationBar.h"

@implementation TMNavigationBar
@synthesize backgroundImage;

+ (UINavigationController*)navigationControllerWithRootViewController:(UIViewController*)aRootViewController
{
    //! load nib named the same as our custom class
    UINib *nib = [UINib nibWithNibName:NSStringFromClass([self class]) bundle:nil];
    
    //! get navigation controller from our xib and pass it the root view controller
    UINavigationController *navigationController = [[nib instantiateWithOwner:nil options:nil] objectAtIndex:0];
    [navigationController setViewControllers:[NSArray arrayWithObject:aRootViewController] animated:NO];
    return navigationController;
}

- (void)drawRect:(CGRect)rect
{
    backgroundImage = nil;
    if (!backgroundImage) {
        backgroundImage = [UIImage imageNamed:@"header_logo_only.png"];
    }
    [backgroundImage drawInRect:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
}

- (void)layoutSubviews {
    self.frame = CGRectMake(0, 0, self.frame.size.width, 62);
}

- (CGSize)sizeThatFits:(CGSize)size {
    CGSize newSize = CGSizeMake(self.frame.size.width,62);
    return newSize;
}

@end
