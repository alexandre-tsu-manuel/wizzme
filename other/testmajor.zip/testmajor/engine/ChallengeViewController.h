//
//  ChallengeViewController.h
//  engine
//
//  Created by Antoine Vigier on 20/10/12.
//
//

#import <UIKit/UIKit.h>
#import <DailymotionSDK/DailymotionSDK.h>


@interface ChallengeViewController : UIViewController <DMPlayerDelegate>

@property (strong, nonatomic) IBOutlet UIView *playerContainerView;
@property (strong, nonatomic) IBOutlet UITableView *tableView;

@end
