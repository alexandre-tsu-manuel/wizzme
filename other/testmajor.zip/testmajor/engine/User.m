//
//  RKUser.m
//  engine
//
//  Created by sattia on 27/07/12.
//
//

#import "User.h"

@implementation User

@synthesize userId;
@synthesize nickname;
@synthesize nbCoins;
@synthesize scoreTotal;
@synthesize facebookLocationId;
@synthesize location;
@synthesize facebookId;
@synthesize thirdPartyId;


/*+ (User *)userWithInfo:(NSDictionary*)userInfo{
    User* u;
    if([userInfo objectForKey:@""]){
        
    }
  
}*/
+ (RKObjectMapping *)objectMapping
{
    RKObjectMapping *mapping = [RKObjectMapping mappingForClass:[self class]];
    [mapping mapKeyPath:@"userId" toAttribute:@"userId"];
    [mapping mapKeyPath:@"facebookId" toAttribute:@"facebookId"];
    [mapping mapKeyPath:@"nickname" toAttribute:@"nickname"];
    [mapping mapKeyPath:@"nbCoins" toAttribute:@"nbCoins"];
    [mapping mapKeyPath:@"scoreTotal" toAttribute:@"scoreTotal"];
    [mapping mapKeyPath:@"location" toAttribute:@"location"];
    [mapping mapKeyPath:@"facebookLocationId" toAttribute:@"facebookLocationId"];
    
    mapping.setNilForMissingRelationships = YES;
    
    return mapping;
}

@end
