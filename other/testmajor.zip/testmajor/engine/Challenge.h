//
//  Challenge.h
//  engine
//
//  Created by sattia on 16/09/12.
//
//

#import <Foundation/Foundation.h>
#import <RestKit/RestKit.h>

@interface Challenge : NSObject
{
    NSString *challengeId;
    NSArray *questionsIds; /*optional*/
    NSString *userId;
    NSNumber *date;
    NSNumber *score;
    NSArray *winners; /*optional*/
}


@property (nonatomic, retain) NSString *challengeId;
@property (nonatomic, retain) NSArray *questionsIds;
@property (nonatomic, retain) NSString *userId;
@property (nonatomic, retain) NSNumber *date;
@property (nonatomic, retain) NSNumber *score;
@property (nonatomic, retain) NSArray *winners;

@end
