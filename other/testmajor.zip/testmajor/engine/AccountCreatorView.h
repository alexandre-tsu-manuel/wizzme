//
//  AccountCreatorView.h
//  engine
//
//  Created by sattia on 16/10/12.
//
//

#import <UIKit/UIKit.h>

@class AccountCreatorView;

@protocol AccountCreatorViewDelegate
- (IBAction)accountCreatorViewOkButtonWasPressed:(id)sender;
- (IBAction)accountCreatorViewCancelButtonWasPressed:(id)sender;
@end

@interface AccountCreatorView : UIView
@property (strong, nonatomic) UITextField *usernameTextField;
@property (strong, nonatomic) UITextField *emailTextField;
@property (strong, nonatomic) UITextField *passwordTextField;
@property (assign) id <AccountCreatorViewDelegate> delegate;

@end
