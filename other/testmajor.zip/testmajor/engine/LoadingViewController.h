//
//  LoadingViewController.h
//  engine
//
//  Created by sattia on 31/07/12.
//
//

#import <UIKit/UIKit.h>

@interface LoadingViewController : UIViewController

@end
