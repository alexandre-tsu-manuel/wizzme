//
//  RKChallenge.h
//  engine
//
//  Created by sattia on 26/07/12.
//
//

#import <Foundation/Foundation.h>
#import <RestKit/RestKit.h>

@interface Test : NSObject{
    
    NSString *testId;
    NSString *type;
    NSString *context;
    NSString *poolId;
    NSString *userId;
    NSString *challengersIds;
    NSString *date;
    NSArray *questions;
    NSNumber *nbrCoins;
    NSString *comment;
}


@property (nonatomic, retain) NSString* testId;
@property (nonatomic, retain) NSString* type;
@property (nonatomic, retain) NSString* context;
@property (nonatomic, retain) NSString* poolId;
@property (nonatomic, retain) NSString* userId;
@property (nonatomic, retain) NSString* challengersIds;
@property (nonatomic, retain) NSString* date;
@property (nonatomic, retain) NSArray* questions;
@property (nonatomic, retain) NSNumber* nbrCoins;
@property (nonatomic, retain) NSString* comment;





+ (RKObjectMapping *)objectMapping;





@end
