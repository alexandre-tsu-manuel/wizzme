//
//  CustomTableViewController.m
//  engine
//
//  Created by sattia on 06/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ChallengeFinderTableViewController.h"
#import "Macros.h"
#import "AppDelegate.h"
#import "MyProfileManager.h"

#import "Challenge.h"
#import "User.h"
#import "AsyncImageView.h"

#import "ChallengeFinderTableViewCell.h"
#import "TestWebService.h"
#import "ChallengeWebService.h"
#import "PlayerFinderViewController.h"
#import "OverlayViewController.h"

#define TITLE_LABEL_TAG 0
#define SUBTITLE_LABEL_TAG 1
#define THUMBNAIL_TAG 2


@interface ChallengeFinderTableViewController ()
- (void)userProfileDidChange:(NSNotification*)notification;
- (void)loadChallengesForUserId:(NSString*)userId;

@property (nonatomic, retain) ChallengeWebService *challengeWebService;
@property (nonatomic, retain) PlayerFinderViewController *playerFinderViewController;

@end

@implementation ChallengeFinderTableViewController

@synthesize dataSource=_dataSource;
@synthesize challengeWebService=_challengeWebService;
@synthesize playerFinderViewController=_playerFinderViewController;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        [self.tableView.backgroundView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        _dataSource=[NSMutableDictionary dictionaryWithCapacity:10];

    }
    return self;
}

-(void)reloadChallenges
{
    NSString *myUserId=[[MyProfileManager sharedInstance]myProfile].userId;
    
    if(myUserId){
        [self loadChallengesForUserId:myUserId];
    }
}

- (void)loadChallengesForUserId:(NSString*)userId
{
    if(_challengeWebService==nil){
        _challengeWebService=[[ChallengeWebService alloc]init];
    }
    [_challengeWebService challengesFromUserId:[MyProfileManager sharedInstance].myProfile.userId poolId:@"questionpool-0" minDate:@"1970-01-03" withCompletionHandler:^(NSArray *receivedChallenges) {
        NSLog(@"Challenge Web Service finished");
        NSMutableArray* arrSectionReceived=[[NSMutableArray alloc]initWithCapacity:2];
        NSMutableArray* arrSectionSent=[[NSMutableArray alloc]initWithCapacity:2];
        NSMutableArray* arrSectionFinished=[[NSMutableArray alloc]initWithCapacity:2];
        
        for(int i=0;i<[receivedChallenges count];i++){
            Challenge *c=[receivedChallenges objectAtIndex:i];
            
            if(c.questionsIds!=nil){
                /*The challenge is pending, it needs an answer*/
                if(c.userId!=nil){
                    if(![c.userId isEqualToString:[MyProfileManager sharedInstance].myProfile.userId]){
                        /*it is the user's turn*/
                        [arrSectionReceived addObject:c];
                        
                    }else{
                        /*it's not the user's turn*/
                        [arrSectionSent addObject:c];
                    }
                }
            }else{
                /*This challenge is finished*/
                [arrSectionFinished addObject:c];
                
            }
        }

        [_dataSource setObject:arrSectionReceived forKey:@"SECTION_RECEIVED"];
        [_dataSource setObject:arrSectionSent forKey:@"SECTION_SENT"];
        [_dataSource setObject:arrSectionFinished forKey:@"SECTION_FINISHED"];
        
        [self.tableView reloadData];
    }];
    
    
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(userProfileDidChange:)
     name:UserProfileChangedNotification
     object:nil];
    
    if([MyProfileManager sharedInstance].myProfile.userId){
        [self loadChallengesForUserId:[MyProfileManager sharedInstance].myProfile.userId];
    }
    
}


-(void)userProfileDidChange:(NSNotification*)notification
{
    NSLog(@"GameFinderTableViewController : userProfileChanged");
    User *updatedProfile=[notification object];
    
    
    /*Update user profile info on the view*/
    
}



- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    //[super dealloc];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [_dataSource count]+1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if(section==0){
        return 1;
    }
    if(section==1){
        return ([[_dataSource objectForKey:@"SECTION_RECEIVED"]count]+1);
    }
    if(section==2){
        return ([[_dataSource objectForKey:@"SECTION_SENT"]count]+1);
    }
    if(section==3){
        NSDictionary *dict=[_dataSource objectForKey:@"SECTION_RECEIVED"];
        return ([[_dataSource objectForKey:@"SECTION_FINISHED"]count]+1);
        
    }
    
    return 0;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
	if([indexPath row] == 0){
		return 47;
	}
    else {
        return 80;
    }
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *CellType1=@"CellType1";
    static NSString *CellType2=@"CellType2";
    
    
    if(indexPath.row==0){
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellType1];
        
        if (cell == nil){
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellType1];
        }
        switch(indexPath.section)
        {
            case 0:
                cell.textLabel.text=@"Nouveau défi";
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                break;
            case 1:
                cell.textLabel.text=@"Défis reçus";
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                break;
            case 2:
                cell.textLabel.text=@"Défis en attente de réponse";
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                break;
            case 3:
                cell.textLabel.text=@"Mes performances";
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                break;
        }
        return cell;
    }
    else{
        ChallengeFinderTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellType2];
        
        if (cell == nil){
            cell = [[ChallengeFinderTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellType2];
        }
        else{
            /*cancel loading previous image for cell*/
            [[AsyncImageLoader sharedLoader] cancelLoadingImagesForTarget:cell.leftThumbnailImageView];
        }
        cell.leftThumbnailImageView.image = [UIImage imageNamed:@"face_placeholder.jpeg"];
  
        
        if(indexPath.section==1){
            if(indexPath.row==0){
                //cell.backgroundView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"header_login_tableView.png"]];
                cell.textLabel.text=@"Défis reçus";
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
            }else{
                Challenge *challenge=[[_dataSource objectForKey:@"SECTION_RECEIVED"]objectAtIndex:indexPath.row-1];
                
                NSString *imageURL =[NSString stringWithFormat:@"http://graph.facebook.com/%@/picture",challenge.userId];
                /*by setting the imageURL the imageView will update automatically*/
                cell.leftThumbnailImageView.imageURL = [NSURL URLWithString:imageURL];
                /*by setting the userId of the cell, it will automatically update the cell with user's data*/
                [cell setUserId:challenge.userId];
                
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"dd-mm-yyyy à hh:mm"];
                NSString *stringFromDate =[formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:[challenge.date doubleValue]]];
                cell.subtitleLabel.text=stringFromDate;
            }
        }
        if(indexPath.section==2){
            if(indexPath.row==0){
                //cell.backgroundView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"header_login_tableView.png"]];
                cell.textLabel.text=@"Défis en attente de réponse";
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
            }else{
                Challenge *challenge=[[_dataSource objectForKey:@"SECTION_SENT"]objectAtIndex:indexPath.row-1];
                
                NSString *imageURL =[NSString stringWithFormat:@"http://graph.facebook.com/%@/picture",challenge.userId];
                /*by setting the imageURL the imageView will update automatically*/
                cell.leftThumbnailImageView.imageURL = [NSURL URLWithString:imageURL];
                /*by setting the userId of the cell, it will automatically update the cell with user's data*/
                [cell setUserId:challenge.userId];
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"dd-mm-yyyy à hh:mm"];
                NSString *stringFromDate =[formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:[challenge.date doubleValue]]];
                cell.subtitleLabel.text=stringFromDate;
            }
        }
        
        if(indexPath.section==3){
            if(indexPath.row==0){
                //cell.backgroundView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"header_login_tableView.png"]];
                cell.textLabel.text=@"Mes performances";
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
            }else{
                Challenge *challenge=[[_dataSource objectForKey:@"SECTION_FINISHED"]objectAtIndex:indexPath.row-1];
                
                NSString *imageURL =[NSString stringWithFormat:@"http://graph.facebook.com/%@/picture",challenge.userId];
                /*by setting the imageURL the imageView will update automatically*/
                cell.leftThumbnailImageView.imageURL = [NSURL URLWithString:imageURL];
                /*by setting the userId of the cell, it will automatically update the cell with user's data*/
                [cell setUserId:challenge.userId];
                
            }
        }
        return cell;
    }
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section==0){
        if(_playerFinderViewController==nil){
            _playerFinderViewController=[[PlayerFinderViewController alloc]init];
        }
        
        [OverlayViewController sharedInstance].view.hidden=FALSE;
        [[OverlayViewController sharedInstance].view addSubview:_playerFinderViewController.view];
    }
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */



@end
