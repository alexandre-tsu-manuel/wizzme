//
//  PlayerFinderTableViewController.m
//  engine
//
//  Created by sattia on 06/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import <FacebookSDK/FacebookSDK.h>

@class ChallengeViewController;

@interface PlayerFinderTableViewController : UITableViewController <UITableViewDelegate,UITableViewDataSource,FBFriendPickerDelegate>
{
    UIImageView* headerImageView;
}

@property (nonatomic, retain) NSDictionary *dataSource;
@property (nonatomic, retain) UIImageView *headerImageView;
@property (strong, nonatomic) NSArray* selectedFriends;
@property (strong) ChallengeViewController *challengeViewController;

@end
