//
//  Challenge.m
//  engine
//
//  Created by sattia on 16/09/12.
//
//

#import "Challenge.h"

@implementation Challenge

@synthesize challengeId;
@synthesize questionsIds;
@synthesize userId;
@synthesize date;
@synthesize score;
@synthesize winners;


+ (RKObjectMapping *)objectMapping
{
    RKObjectMapping *mapping = [RKObjectMapping mappingForClass:[self class]];
    [mapping mapKeyPath:@"id" toAttribute:@"challengeId"];
    [mapping mapKeyPath:@"questionsIds" toAttribute:@"questionsIds"];
    [mapping mapKeyPath:@"userId" toAttribute:@"userId"];
    [mapping mapKeyPath:@"date" toAttribute:@"date"];
    [mapping mapKeyPath:@"score" toAttribute:@"score"];
    [mapping mapKeyPath:@"winners" toAttribute:@"winners"];
    
    
    mapping.setNilForMissingRelationships = YES;
    
    return mapping;
}


@end
