//
//  ChallengeFinderTableViewCell.m
//  engine
//
//  Created by sattia on 28/07/12.
//
//

#import "ChallengeFinderTableViewCell.h"
#import "UserWebService.h"
#import "ChallengeWebService.h"
#import "User.h"

@interface ChallengeFinderTableViewCell ()

@property (nonatomic, retain) UserWebService *userWebService;

@end

@implementation ChallengeFinderTableViewCell
@synthesize leftThumbnailImageView=_leftThumbnailImageView;
@synthesize titleLabel=_titleLabel;
@synthesize subtitleLabel=_subtitleLabel;
@synthesize userId=_userId;
@synthesize userWebService=_userWebService;


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        _titleLabel=[[UILabel alloc]init];
        _titleLabel.font = [UIFont systemFontOfSize:17.0];
        _titleLabel.textAlignment = UITextAlignmentLeft;
        _titleLabel.backgroundColor=[UIColor clearColor];
        [self.contentView addSubview:_titleLabel];
        
        _subtitleLabel=[[UILabel alloc]init];
        _subtitleLabel.font = [UIFont systemFontOfSize:12.0];
        _subtitleLabel.textColor = [UIColor darkGrayColor];
        _subtitleLabel.backgroundColor=[UIColor clearColor];
        _subtitleLabel.textAlignment = UITextAlignmentLeft;
        [self.contentView addSubview:_subtitleLabel];
        
        
        _leftThumbnailImageView=[[UIImageView alloc]init];
        _leftThumbnailImageView.contentMode = UIViewContentModeScaleAspectFit;
        [self.contentView addSubview:_leftThumbnailImageView];
        
        
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect contentRect = self.contentView.bounds;
    CGFloat boundsX = contentRect.origin.x;
    CGRect frame;
    frame= CGRectMake(0 ,0, 65, 75);
    _leftThumbnailImageView.frame = frame;
    
    frame= CGRectMake(boundsX+70 ,5, 200, 25);
    _titleLabel.frame = frame;
    
    frame= CGRectMake(boundsX+70 ,30, contentRect.size.width, 15);
    _subtitleLabel.frame = frame;
}

-(void)setUserId:(NSString *)userId
{
    /*if the user id changed, re-download the corresponding user profile*/
    /*else do nothing*/
    
    if(_userId!=userId){
    _userId=userId;
    if(_userWebService==nil){
        _userWebService=[[UserWebService alloc]init];
        [_userWebService setDelegate:self];
    }
    [_userWebService userFromUserId:userId];
    }
    
}

-(void)userWebService:(UserWebService *)webService didReceiveUsers:(NSArray *)usersArray
{
    User* user=[usersArray objectAtIndex:0];
    _titleLabel.text=user.nickname;
    
}

-(void)userWebService:(UserWebService *)webService didFailWithError:(NSError *)error
{
    NSLog(@"ChallengeFinderTableViewCell : Couldn't get user using userWebService");
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
