//
//  CustomTableViewController.m
//  engine
//
//  Created by sattia on 06/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "LoginTableViewController.h"
#import "Macros.h"
#import "AppDelegate.h"
#import "AccountCreatorViewController.h"
#import "OverlayViewController.h"

#define TITLE_LABEL_TAG 0
#define SUBTITLE_LABEL_TAG 1
#define THUMBNAIL_TAG 2



@interface LoginTableViewController ()
{
    UserWebService* userWebService;
}

@property (nonatomic, retain) UserWebService *userWebService;


- (void)performFacebookLogin;
- (void)loginFailed;


@end

@implementation LoginTableViewController

@synthesize dataSource=_dataSource;
@synthesize headerImageView=_headerImageView;
@synthesize userWebService=_userWebService;


- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        NSLog(@"LoginTableViewController");
        UIImageView* tableViewHeaderImageView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"header_login_tableView.png"]];
        _dataSource = [NSDictionary dictionaryWithObjectsAndKeys:
                       @"2",@"row_count",
                       @"facebook", TITLE_KEY_FROM_INDEXPATH(0),
                       @"Nous ne publions jamais sans ton autorisation",SUBTITLE_KEY_FROM_INDEXPATH(0),
                       @"E-mail",TITLE_KEY_FROM_INDEXPATH(1),
                       @"Nous t'enverrons un e-mail la première fois",SUBTITLE_KEY_FROM_INDEXPATH(1),
                       @"facebook_thumbnail.png",THUMBNAILURL_KEY_FROM_INDEXPATH(0),
                       @"facebook_thumbnail.png",THUMBNAILURL_KEY_FROM_INDEXPATH(1),
                       tableViewHeaderImageView, @"header_background",nil];
        
    }
    return self;
}



-(void)userWebService:(UserWebService *)webService didCreateUserAccountWithData:(NSDictionary *)data
{
    NSLog(@"LoginTableViewController : UserWebService did create user with data");
    AppDelegate* appDelegate =(AppDelegate *) [UIApplication sharedApplication].delegate;
    [appDelegate openEmailSession];
}

- (void)performFacebookLogin
{
    AppDelegate* appDelegate =(AppDelegate *) [UIApplication sharedApplication].delegate;
    [appDelegate openFacebookSession];
}

- (void)loginFailed
{
    // User switched back to the app without authorizing. Stay here, but
    // stop the spinner.
    
}


- (void)viewDidLoad
{
    
    self.tableView.backgroundColor=[UIColor clearColor];
    //self.tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth;
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    _headerImageView=[_dataSource objectForKey:@"header_background"];
    
    [self.tableView reloadData];
    
    [super viewDidLoad];
    
}



- (void)dealloc
{
    //[super dealloc];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Number of rows is the number of time zones in the region for the specified section.
    return [[_dataSource objectForKey:ROW_COUNT] intValue]+1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
	if([indexPath row] == 0){
		return 47;
	}
    else {
        return 80;
    }
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"Cell";
    NSLog(@"cell for row at index path");
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:CellIdentifier];
    }
    
    if(indexPath.row==0){
        cell.backgroundView=_headerImageView;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
    }
    else{
        
        
        UIImageView* leftThumbnailImageView=[[UIImageView alloc]initWithFrame:CGRectMake(0,0, 55, 55)];
        leftThumbnailImageView.image=[UIImage imageNamed:[_dataSource objectForKey:THUMBNAILURL_KEY_FROM_INDEXPATH(indexPath.row-1)]];
        leftThumbnailImageView.tag=THUMBNAIL_TAG;
        
        [cell.contentView addSubview:leftThumbnailImageView];
        
        UILabel *title, *subtitle;
        title = [[UILabel alloc] initWithFrame:CGRectMake(65, 10, 220, 15)];
        title.tag = TITLE_LABEL_TAG;
        title.font = [UIFont systemFontOfSize:17.0];
        title.text=[_dataSource objectForKey:TITLE_KEY_FROM_INDEXPATH(indexPath.row-1)];
        title.textAlignment = UITextAlignmentLeft;
        title.backgroundColor=[UIColor clearColor];
        
        subtitle = [[UILabel alloc] initWithFrame:CGRectMake(65, 30, 220, 15)];
        subtitle.tag = SUBTITLE_LABEL_TAG;
        subtitle.text=[_dataSource objectForKey:SUBTITLE_KEY_FROM_INDEXPATH(indexPath.row-1)];
        subtitle.font = [UIFont systemFontOfSize:12.0];
        subtitle.textColor = [UIColor darkGrayColor];
        subtitle.backgroundColor=[UIColor clearColor];
        subtitle.textAlignment = UITextAlignmentLeft;
        
        
        [cell.contentView addSubview:leftThumbnailImageView];
        [cell.contentView addSubview:title];
        [cell.contentView addSubview:subtitle];
        
        
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row==1){
        //Facebook login selected
        [self performFacebookLogin];
    }
    if(indexPath.row==2){
        
        UIAlertView *promptAlertView = [[UIAlertView alloc] initWithTitle:@"Que veux-tu faire ?" message:@"Choisis parmis ces deux options" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:nil];
        [promptAlertView addButtonWithTitle:@"Creer un compte"];
        [promptAlertView addButtonWithTitle:@"Me connecter"];
        [promptAlertView show];
    }
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if(buttonIndex==1)
    {
        /*Create a new account*/
        AccountCreatorViewController *accountCreatorViewController=[[AccountCreatorViewController alloc]init];
        accountCreatorViewController.modalTransitionStyle=UIModalTransitionStyleFlipHorizontal;
        [self presentViewController:accountCreatorViewController animated:TRUE completion:^{
        }];
    }
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */



@end
