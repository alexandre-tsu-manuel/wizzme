//
//  BuyCoinsViewController.h
//  engine
//
//  Created by sattia on 09/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BuyCoinsTableViewController.h"

@interface BuyCoinsViewController : UIViewController
{
    BuyCoinsTableViewController* tableViewController;
}

@property (strong, nonatomic) BuyCoinsTableViewController *tableViewController;

@end
