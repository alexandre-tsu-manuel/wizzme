//
//  LoginViewController.m
//  engine
//
//  Created by sattia on 06/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "LoginViewController.h"
#import "LoginTableViewController.h"
#import "Macros.h"
#import "AppDelegate.h"



@interface LoginViewController ()

-(void)drawUserInterface;


@end

@implementation LoginViewController
@synthesize tableViewController=_tableViewController;
@synthesize spinner=_spinner;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}


-(void)drawUserInterface
{
    UIImageView* backgroundImageView = [[UIImageView alloc]initWithFrame:
                                        CGRectMake(0.f, 0.f, kScreenWidth, self.view.frame.size.height)];
    backgroundImageView.image=[UIImage imageNamed:@"background.png"];
    
    
    
    UIView* tableViewWrapper=[[UIView alloc]initWithFrame:CGRectMake(0.f, 0.f, 320.f, self.view.frame.size.height)];
    tableViewWrapper.backgroundColor=[UIColor clearColor];
    
    _tableViewController=[[LoginTableViewController alloc]initWithStyle:UITableViewStyleGrouped];
    [_tableViewController.tableView setContentInset:UIEdgeInsetsMake(50.f, 0.f, 0.f, 0.f)];
     [_tableViewController.tableView.backgroundView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    [tableViewWrapper addSubview:_tableViewController.tableView];
    
    [self.view addSubview:backgroundImageView];
    [self.view addSubview:tableViewWrapper];
}

-(void)loginFailed
{
    NSLog(@"LOGIN FAILED");
}



- (void)viewDidLoad
{
    [super viewDidLoad];
    [self drawUserInterface];
}

- (void)dealloc
{
    //[super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
