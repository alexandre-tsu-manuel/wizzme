//
//  ChallengeWebService.m
//  engine
//
//  Created by sattia on 28/07/12.
//
//

#import "UserWebService.h"
#import "Macros.h"
#import "User.h"
#import <RestKit/RKJSONParserJSONKit.h>
#import <FacebookSDK/FacebookSDK.h>
#import "MyProfileManager.h"


#define ADD_USER_RESOURCE [NSString stringWithFormat:@"/_users/_design/user/_update/add-user"]
#define ME_STATIC_URL [NSString stringWithFormat:@"/me.json"]
#define USER_RESOURCE_WITH_USER_ID(id) [NSString stringWithFormat:@"/_users/_design/user/_show/asArray/org.couchdb.user:%@",id]
#define LOGIN_URL [NSString stringWithFormat:@"/_session"]

@interface UserWebService()

@end

@implementation UserWebService
@synthesize delegate=_delegate;


void (^_userForUserIdCompletionHandler)(User *receivedUser);

void (^_createUserWithInfoCompletionHandler)(NSString *completionStatus);
void (^_loginCompletionHandler)(NSString *completionStatus);



- (void)userFromUserId:(NSString *)userId
{
    RKObjectMapping *userMapping=[User objectMapping];
    [[RKObjectManager sharedManager].mappingProvider setMapping:userMapping forKeyPath:@"user"];
    NSString* dbUserId=[NSString stringWithFormat:@"org.couchdb.user:%@",userId];
    [[RKObjectManager sharedManager] loadObjectsAtResourcePath:USER_RESOURCE_WITH_USER_ID(userId) delegate:self];
}

- (void)userFromUserId:(NSString *)userId withCompletionHandler:(void (^)(User *receivedUser))handler
{
    _userForUserIdCompletionHandler = [handler copy];
    RKObjectMapping *userMapping=[User objectMapping];
    [[RKObjectManager sharedManager].mappingProvider setMapping:userMapping forKeyPath:@"user"];
    [[RKObjectManager sharedManager] loadObjectsAtResourcePath:USER_RESOURCE_WITH_USER_ID(userId) delegate:self];
}



- (void)createUserWithInfo:(NSDictionary *)userInfo withCompletionHandler:(void (^)(NSString* completionStatus))handler
{
    _createUserWithInfoCompletionHandler = [handler copy];
    NSArray *allKeys=[userInfo allKeys];
    
    NSString *urlString=@"";
    urlString=[NSString stringWithFormat:@"%@/?",ADD_USER_RESOURCE];
    
    /*Dynamic URL generation functions of userInfo content*/
    for(int i=0;i<[allKeys count];i++){
        NSString *valueForKey=[userInfo valueForKey:[allKeys objectAtIndex:i]];
        if(i<[allKeys count]-1){
            urlString=[urlString stringByAppendingString:[NSString stringWithFormat:@"%@=%@&",[allKeys objectAtIndex:i],valueForKey]];
        }
        else{
            urlString=[urlString stringByAppendingString:[NSString stringWithFormat:@"%@=%@",[allKeys objectAtIndex:i],valueForKey]];
        }
    }
    NSLog(@"URL STRING=%@",urlString);
    [[RKClient sharedClient] put:urlString params:nil delegate:self];

}



-(void)request:(RKRequest *)request didLoadResponse:(RKResponse *)response
{
    NSLog(@"Response=%@",[response bodyAsString]);
    
    if(request.isPUT==YES){
        RKJSONParserJSONKit *parser=[[RKJSONParserJSONKit alloc]init];
        NSDictionary * dict=[parser objectFromString:[response bodyAsString] error:nil];
        
        if([[dict objectForKey:@"status"]isEqualToString:@"OK"]){
            _createUserWithInfoCompletionHandler(@"ACCOUNT_CREATED_OK");
        }else if([[dict objectForKey:@"error"]isEqualToString:@"conflict"]){
            _createUserWithInfoCompletionHandler(@"ACCOUNT_ALREADY_EXISTS");
        }
        else
        {
            NSLog(@"UserWebService : Error in User account creation");
            _createUserWithInfoCompletionHandler(@"ERROR_CREATING_ACCOUNT");
        }
    }
    else {
        
    }
}

-(void)request:(RKRequest *)request didFailLoadWithError:(NSError *)error
{
    NSLog(@"ERROR in UserWebService=%@",error);
}


- (void)objectLoader:(RKObjectLoader*)objectLoader didLoadObjects:(NSArray*)objects
{
    
    if(_delegate!=nil){
        [_delegate userWebService:self didReceiveUsers:objects];
    }
    else if(_userForUserIdCompletionHandler!=nil){
        
        _userForUserIdCompletionHandler([objects objectAtIndex:0]);
    }
}

- (void)objectLoader:(RKObjectLoader*)objectLoader didFailWithError:(NSError*)error
{
    RKLogError(@"Error: %@", error);
    if(_delegate!=nil){
        [_delegate userWebService:self didFailWithError:error];
    }
    _userForUserIdCompletionHandler=nil;
}

@end
