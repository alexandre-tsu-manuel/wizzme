//
//  BuyCoinsTableViewController.m
//  engine
//
//  Created by sattia on 09/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "BuyCoinsTableViewController.h"
#import "Macros.h"

#define TITLE_LABEL_TAG 0
#define SUBTITLE_LABEL_TAG 1
#define THUMBNAIL_TAG 2

@interface BuyCoinsTableViewController ()

@end

@implementation BuyCoinsTableViewController
@synthesize headerImageView=_headerImageView;
@synthesize dataSource=_dataSource;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        UIImageView* tableViewHeaderImageView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"header_login_tableView.png"]];
        _dataSource = [NSDictionary dictionaryWithObjectsAndKeys:
                       @"4",@"row_count",
                       @"400 pièces", TITLE_KEY_FROM_INDEXPATH(0), 
                       @"",SUBTITLE_KEY_FROM_INDEXPATH(0), 
                       @"1200 pièces",TITLE_KEY_FROM_INDEXPATH(1), 
                       @"-15%",SUBTITLE_KEY_FROM_INDEXPATH(1), 
                       @"3000 pièces",TITLE_KEY_FROM_INDEXPATH(2), 
                       @"-33%",SUBTITLE_KEY_FROM_INDEXPATH(2),
                       @"10 000 pièces",TITLE_KEY_FROM_INDEXPATH(3), 
                       @"-50%",SUBTITLE_KEY_FROM_INDEXPATH(3),
                       @"facebook_thumbnail.png",THUMBNAILURL_KEY_FROM_INDEXPATH(0),
                       @"facebook_thumbnail.png",THUMBNAILURL_KEY_FROM_INDEXPATH(1),
                       @"facebook_thumbnail.png",THUMBNAILURL_KEY_FROM_INDEXPATH(2),
                       @"facebook_thumbnail.png",THUMBNAILURL_KEY_FROM_INDEXPATH(3),
                       tableViewHeaderImageView, @"header_background",nil];
    }
    return self;
}

- (void)viewDidLoad
{
    
    self.tableView.backgroundColor=[UIColor clearColor];
    //self.tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth;
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    _headerImageView=[_dataSource objectForKey:@"header_background"];
    [self.tableView setContentInset:UIEdgeInsetsMake(15,0,0,0)];
    
    [self.tableView reloadData];
    
    [super viewDidLoad];
    
}

- (void)dealloc
{
    //[super dealloc];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Number of rows is the number of time zones in the region for the specified section.
    return [[_dataSource objectForKey:ROW_COUNT] intValue]+1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
	if([indexPath row] == 0){
		return 47;
	}
    else {
        return 80;
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                      reuseIdentifier:CellIdentifier];
    }
    
    if(indexPath.row==0){
        cell.backgroundView=_headerImageView;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
    }
    else{
        
        
        UIImageView* leftThumbnailImageView=[[UIImageView alloc]initWithFrame:CGRectMake(0,0, 55, 55)];
        leftThumbnailImageView.image=[UIImage imageNamed:[_dataSource objectForKey:THUMBNAILURL_KEY_FROM_INDEXPATH(indexPath.row-1)]];
        leftThumbnailImageView.tag=THUMBNAIL_TAG;
        
        [cell.contentView addSubview:leftThumbnailImageView];
        
        UILabel *title, *subtitle;
        title = [[UILabel alloc] initWithFrame:CGRectMake(65, 10, 220, 15)];
        title.tag = TITLE_LABEL_TAG;
        title.font = [UIFont systemFontOfSize:17.0];
        title.text=[_dataSource objectForKey:TITLE_KEY_FROM_INDEXPATH(indexPath.row-1)];
        title.textAlignment = UITextAlignmentLeft;
        title.backgroundColor=[UIColor clearColor];
        
        subtitle = [[UILabel alloc] initWithFrame:CGRectMake(65, 30, 220, 15)];
        subtitle.tag = SUBTITLE_LABEL_TAG;
        subtitle.text=[_dataSource objectForKey:SUBTITLE_KEY_FROM_INDEXPATH(indexPath.row-1)];
        subtitle.font = [UIFont systemFontOfSize:12.0];
        subtitle.textColor = [UIColor darkGrayColor];
        subtitle.backgroundColor=[UIColor clearColor];
        subtitle.textAlignment = UITextAlignmentLeft;
        
        
        [cell.contentView addSubview:leftThumbnailImageView];
        [cell.contentView addSubview:title];
        [cell.contentView addSubview:subtitle];
        
        
    }
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     */
}

@end
