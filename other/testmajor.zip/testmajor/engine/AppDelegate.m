//
//  AppDelegate.m
//  engine
//
//  Created by sattia on 06/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AppDelegate.h"
#import "LoginViewController.h"
#import "TMNavigationBar.h"
#import "BuyCoinsViewController.h"
#import "ChallengeFinderViewController.h"
#import "Macros.h"
#import "MyProfileManager.h"


#import "LoadingViewController.h"
#import <Security/Security.h>
#import "OverlayViewController.h"

#import "TestWebService.h"
#import "Challenge.h"

#define ME_STATIC_URL [NSString stringWithFormat:@"/me.json"]

NSString *const SCSessionStateChangedNotification = @"SCSessionStateChangedNotification";


@interface AppDelegate ()

-(void)showLoginView;

/*View Controllers*/
@property (strong, nonatomic) ChallengeFinderViewController *challengeFinderViewController;
@property (strong, nonatomic) LoadingViewController *loadingViewController;

/*Web Services*/
@property (strong, nonatomic) UserWebService *userWebService;
@property (strong, nonatomic) StartupWebService *startupWebService;
@property (strong, nonatomic) TestWebService *testWebService;

@end


@implementation AppDelegate

@synthesize window = _window;
@synthesize navigationController = _navigationController;
@synthesize challengeFinderViewController = _challengeFinderViewController;
@synthesize startupWebService=_startupWebService;
@synthesize userWebService=_userWebService;
@synthesize loadingViewController=_loadingViewController;

@synthesize testWebService=_testWebService;

-(BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    /*Initialization of the RestKit object for REST request*/
    RKClient *client = [RKClient clientWithBaseURLString:TESTMAJOR_BASE_SERVER];
    [RKClient sharedClient].username=API_USERNAME;
    [RKClient sharedClient].password=API_PASSWORD;
    [RKClient setSharedClient:client];
    [[RKClient sharedClient]setAuthenticationType:RKRequestAuthenticationTypeHTTPBasic];
    
    RKObjectManager* objectManager = [RKObjectManager objectManagerWithBaseURL:[NSURL URLWithString:TESTMAJOR_BASE_SERVER]];
    [RKObjectManager sharedManager].serializationMIMEType = RKMIMETypeJSON;
    objectManager.client.username=API_USERNAME;
    objectManager.client.password=API_PASSWORD;
    objectManager.acceptMIMEType = RKMIMETypeJSON;
    objectManager.serializationMIMEType = RKMIMETypeJSON;
    [RKObjectManager setSharedManager:objectManager];
    
    
    [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationFade];
    [FBProfilePictureView class];
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.challengeFinderViewController = [[ChallengeFinderViewController alloc] init];
    self.loadingViewController = [[LoadingViewController alloc] init];
    
    self.navigationController=[TMNavigationBar navigationControllerWithRootViewController:self.challengeFinderViewController];
    self.navigationController.delegate=self;
    self.window.rootViewController = self.navigationController;
    
    /*the OverlayViewController will appear on top of all the screen when needed*/
    OverlayViewController *overlayViewController=[OverlayViewController sharedInstance];
    [self.window.rootViewController.view addSubview:overlayViewController.view];
    [self.window makeKeyAndVisible];
    
    
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *username=[[defaults objectForKey:@"credentials"]objectForKey:@"username"];
    NSString *password=[[defaults objectForKey:@"credentials"]objectForKey:@"password"];
    
    /*Case <credentials stored locally>*/
    if(username!=nil && password!=nil){
        // FBSession logic
        if (FBSession.activeSession.state == FBSessionStateCreatedTokenLoaded) {
            [self openFacebookSession];
            
        } else {
            /*Case <email login>*/
            [[MyProfileManager sharedInstance]getMyProfileWithCompletionHandler:^(User *userProfile) {
                NSLog(@"TM User profile received = %@",userProfile);
                UIViewController *topViewController = [self.navigationController topViewController];
                [topViewController dismissModalViewControllerAnimated:YES];
                [(ChallengeFinderViewController*)[self.navigationController topViewController]reloadChallenges];
            }];
        }
    }else{
        /*Case <no credentials locally>*/
        [self showLoginView];
    }
    
    
    
    return YES;
}


- (void)showLoginView {
    UIViewController *topViewController = [self.navigationController topViewController];
    UIViewController *modalViewController = [topViewController modalViewController];
    
    // FBSample logic
    // If the login screen is not already displayed, display it. If the login screen is displayed, then
    // getting back here means the login in progress did not successfully complete. In that case,
    // notify the login view so it can update its UI appropriately.
    
    if (![modalViewController isKindOfClass:[LoginViewController class]]) {
        LoginViewController* loginViewController = [[LoginViewController alloc]init];
        [topViewController presentModalViewController:loginViewController animated:NO];
    } else {
        LoginViewController* loginViewController = (LoginViewController*)modalViewController;
        [loginViewController loginFailed];
    }
}


- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation
{
    return [FBSession.activeSession handleOpenURL:url];
}

-(void)createUserAccountWithFBData{
    
}


- (void)sessionStateChanged:(FBSession *)session
                      state:(FBSessionState) state
                      error:(NSError *)error
{
    switch (state) {
        case FBSessionStateOpen: {
            UIViewController *topViewController = [self.navigationController topViewController];
            
            if ([[topViewController modalViewController] isKindOfClass:[LoginViewController class]]) {
                
                [[MyProfileManager sharedInstance] myFacebookUserInfoWithCompletionHandler:^(NSDictionary *facebookUserProfile) {
                    NSLog(@"Facebook User Info downloaded...");
                    
                    if(_userWebService==nil){
                        _userWebService=[[UserWebService alloc]init];
                    }
                    
                    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                    NSMutableDictionary *credentials=[[NSMutableDictionary alloc]initWithCapacity:2];
                    [credentials setObject:[facebookUserProfile objectForKey:@"id"]forKey:@"username"];
                    [credentials setObject:[facebookUserProfile objectForKey:@"third_party_id"]forKey:@"password"];
                    [defaults setObject:credentials forKey:@"credentials"];
                    [defaults synchronize];
                    
                    NSLog(@"Third_party_id=%@",[facebookUserProfile objectForKey:@"third_party_id"]);
                    
                    /*Creating userInfo dictionnary formated to fit UserWebService*/
                    NSMutableDictionary *userInfo=[[NSMutableDictionary alloc]initWithCapacity:2];
                    
                    if([facebookUserProfile objectForKey:@"third_party_id"]!=nil){
                    [userInfo setObject:[facebookUserProfile objectForKey:@"third_party_id"] forKey:@"password"];
                    }
                    
                    if([facebookUserProfile objectForKey:@"name"]!=nil){
                    [userInfo setObject:[facebookUserProfile objectForKey:@"name"] forKey:@"username"];
                    }
                    
                    if([facebookUserProfile objectForKey:@"id"]!=nil){
                    [userInfo setObject:[facebookUserProfile objectForKey:@"id"] forKey:@"facebookId"];
                    }
                    
                    if([facebookUserProfile objectForKey:@"location"]!=nil){
                    [userInfo setObject:[[facebookUserProfile objectForKey:@"location"]objectForKey:@"id"] forKey:@"facebookLocationId"];
                    }
                    
                    /*Creating user profile on server if it doesn't exist*/
                    [_userWebService createUserWithInfo:userInfo withCompletionHandler:^(NSString *completionStatus) {
                        NSLog(@"User account created on TM server...");
                        
                        [[MyProfileManager sharedInstance]getMyProfileWithCompletionHandler:^(User *userProfile) {
                            NSLog(@"TM User profile received = %@",userProfile);
                            UIViewController *topViewController = [self.navigationController topViewController];
                            [topViewController dismissModalViewControllerAnimated:YES];
                            [(ChallengeFinderViewController*)[self.navigationController topViewController]reloadChallenges];
                        }];
                        
                    }];
                }];
            }else{
                /*If the session is already open, get the userProfile from the TM Server*/
                [[MyProfileManager sharedInstance]getMyProfileWithCompletionHandler:^(User *userProfile) {
                    NSLog(@"TM User profile received = %@",userProfile);
                    UIViewController *topViewController = [self.navigationController topViewController];
                    [topViewController dismissModalViewControllerAnimated:YES];
                    [(ChallengeFinderViewController*)[self.navigationController topViewController]reloadChallenges];
                }];
            }
        }
            
            break;
        case FBSessionStateClosed:
        case FBSessionStateClosedLoginFailed:
            // Once the user has logged in, we want them to
            // be looking at the root view.
            [self.navigationController popToRootViewControllerAnimated:NO];
            
            [FBSession.activeSession closeAndClearTokenInformation];
            
            [self showLoginView];
            break;
        default:
            break;
    }
    
    [[NSNotificationCenter defaultCenter]
     postNotificationName:SCSessionStateChangedNotification
     object:session];
    
    if (error) {
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Error"
                                  message:error.localizedDescription
                                  delegate:nil
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil];
        [alertView show];
    }
}



- (void)openFacebookSession
{
    
    [FBSession openActiveSessionWithReadPermissions:nil
                                       allowLoginUI:YES
                                  completionHandler:
     ^(FBSession *session,
       FBSessionState state, NSError *error) {
         [self sessionStateChanged:session state:state error:error];
     }];
}

- (void)openEmailSession
{
    NSLog(@"AppDelegate : openEmailSession()");
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
    return TRUE;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    
    // this means the user switched back to this app without completing
    // a login in Safari/Facebook App
    if (FBSession.activeSession.state == FBSessionStateCreatedOpening) {
        [FBSession.activeSession close]; // so we close our session and start over
    }
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
