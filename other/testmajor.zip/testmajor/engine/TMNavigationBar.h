//
//  TMNavigationBar.h
//  engine
//
//  Created by sattia on 06/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMNavigationBar : UINavigationBar
{
    
    UIImage *backgroundImage;
}

@property (strong, nonatomic) UIImage *backgroundImage;

+ (UINavigationController*)navigationControllerWithRootViewController:(UIViewController*)aRootViewController;
@end
