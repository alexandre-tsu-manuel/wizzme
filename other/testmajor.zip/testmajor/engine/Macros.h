//
//  Macros.h
//  engine
//
//  Created by sattia on 09/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

/***************************************Global Macros**************************************************/
#define kScreenWidth [[UIScreen mainScreen] bounds].size.width
#define kScreenHeight [[UIScreen mainScreen] bounds].size.height

/*Address of our data API*/
#define TESTMAJOR_BASE_SERVER [NSString stringWithFormat:@"https://testmajor.cloudant.com"]
#define TESTMAJOR_BASE_SERVER_LOCAL [NSString stringWithFormat:@"http://127.0.0.1/testmajor/json_examples"]

//#define API_USERNAME [NSString stringWithFormat:@"pilipmalette@gmail.com"]
//#define API_PASSWORD [NSString stringWithFormat:@"loopings"]

#define API_USERNAME [NSString stringWithFormat:@"testmajor"]
#define API_PASSWORD [NSString stringWithFormat:@"loopings8"]
/******************************************************************************************************/


/***************************************TableViewControllers*******************************************/
#define TITLE_KEY_FROM_INDEXPATH(i) [NSString stringWithFormat:@"row%d_title",i]
#define SUBTITLE_KEY_FROM_INDEXPATH(i) [NSString stringWithFormat:@"row%d_subtitle",i]
#define ROW_COUNT [NSString stringWithFormat:@"row_count"]
#define THUMBNAILURL_KEY_FROM_INDEXPATH(i) [NSString stringWithFormat:@"row%d_thumbnailURL",i]
/***************************************TableViewControllers*******************************************/
