//
//  AccountCreatorView.m
//  engine
//
//  Created by sattia on 16/10/12.
//
//

#import "AccountCreatorView.h"


@implementation AccountCreatorView

@synthesize usernameTextField=_usernameTextField;
@synthesize emailTextField=_emailTextField;
@synthesize passwordTextField=_passwordTextField;
@synthesize delegate = _delegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _usernameTextField = [[UITextField alloc] initWithFrame:CGRectMake(20, 45.0, 260.0, 25.0)];
        _emailTextField = [[UITextField alloc] initWithFrame:CGRectMake(20, 85.0, 260.0, 25.0)];
        _passwordTextField = [[UITextField alloc] initWithFrame:CGRectMake(20, 125.0, 260.0, 25.0)];
        
        _emailTextField.backgroundColor=[UIColor whiteColor];
        _passwordTextField.backgroundColor=[UIColor whiteColor];
        _usernameTextField.backgroundColor=[UIColor whiteColor];
        
        _usernameTextField.text=@"Votre nom";
        _emailTextField.text=@"Votre email";
        _passwordTextField.text=@"Votre mot de passe";
        
        UIButton *okButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        okButton.frame = CGRectMake(200, 200, 100, 22);
        [okButton setTitle:@"Valider" forState:UIControlStateNormal];
        [okButton addTarget:_delegate action:@selector(accountCreatorViewOkButtonWasPressed:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:okButton];
        
        UIButton *cancelButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        cancelButton.frame = CGRectMake(100, 200, 100, 22);
        [cancelButton setTitle:@"Annuler" forState:UIControlStateNormal];
        [cancelButton addTarget:_delegate action:@selector(accountCreatorViewCancelButtonWasPressed:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:cancelButton];
        
        
        [self addSubview:_emailTextField];
        [self addSubview:_passwordTextField];
        [self addSubview:_usernameTextField];
    }
    return self;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

@end
