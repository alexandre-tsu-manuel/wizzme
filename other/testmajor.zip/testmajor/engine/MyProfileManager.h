//
//  TMProfileManager.h
//  engine
//
//  Created by sattia on 16/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "User.h"
#import <RestKit/RestKit.h>
#import "UserWebService.h"
#import <FacebookSDK/FacebookSDK.h>

extern NSString *const UserProfileChangedNotification;

@interface MyProfileManager : NSObject



/*This is the user id of the user profile to be managed (needs to be set)*/
@property (strong, nonatomic) NSString *userId;
/*Contains the most recent user profile, nil if never retrieved*/
@property (strong, nonatomic) User *myProfile;
/*The class in charge of the profile fetch from the server*/
@property (strong, nonatomic) UserWebService *userWebService;
/*The third_party_id property from the facebook user profile[needs auth token] */
@property (strong, nonatomic) NSString *facebookThirdPartyId;


+ (MyProfileManager *)sharedInstance;
-(void)getMyProfileWithCompletionHandler:(void (^)(User *userProfile))handler;
- (void)myFacebookUserInfoWithCompletionHandler:(void (^)(NSDictionary *facebookUserInfo))handler;


@end
