//
//  ChallengeFinderViewController.m
//  engine
//
//  Created by sattia on 09/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ChallengeFinderViewController.h"
#import "Macros.h"
#import "AppDelegate.h"
#import "StartupWebService.h"
#import "MyProfileManager.h"

@interface ChallengeFinderViewController ()

-(void)loadUserProfile;


@property (strong, nonatomic) FBProfilePictureView *userProfileImage;
@property (strong, nonatomic) UILabel *userNameLabel;




@end

@implementation ChallengeFinderViewController
@synthesize userNameLabel,userProfileImage;



@synthesize tableViewController=_tableViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    [self reloadChallenges];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self reloadChallenges];
    [[NSNotificationCenter defaultCenter] 
     addObserver:self 
     selector:@selector(sessionStateChanged:) 
     name:SCSessionStateChangedNotification
     object:nil];
    
    UIImageView* backgroundImageView = [[UIImageView alloc]initWithFrame:
                                        CGRectMake(0, 0, kScreenWidth, self.view.frame.size.height)];
    backgroundImageView.image=[UIImage imageNamed:@"background.png"];

    
    if(_tableViewController==nil){
    _tableViewController=[[ChallengeFinderTableViewController alloc]initWithStyle:UITableViewStyleGrouped];
    }
    [_tableViewController.tableView setContentInset:UIEdgeInsetsMake(0,0,0,0)];
    
   [self.view addSubview:backgroundImageView];
   [self.view addSubview:_tableViewController.tableView];
     
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] 
                                             initWithTitle:@"Logout"
                                             style:UIBarButtonItemStyleBordered
                                             target:self
                                             action:@selector(logoutButtonWasPressed:)];  
    
    userNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(65, 10, 220, 15)];
    userNameLabel.font = [UIFont systemFontOfSize:17.0];
    userNameLabel.textAlignment = UITextAlignmentLeft;
    userNameLabel.backgroundColor=[UIColor clearColor];
    
    userProfileImage=[[FBProfilePictureView alloc]initWithFrame:CGRectMake(0, 0, 50, 50)];
    UIBarButtonItem *profilePictureButton = [[UIBarButtonItem alloc] initWithCustomView:userProfileImage];
    self.navigationItem.rightBarButtonItem = profilePictureButton;
}

- (void)reloadChallenges
{
    if(_tableViewController!=nil){
        [_tableViewController reloadChallenges];
    }
}
- (void)loadUserProfile
{
    if (FBSession.activeSession.isOpen) {
        [[FBRequest requestForMe] startWithCompletionHandler:
         ^(FBRequestConnection *connection, 
           NSDictionary<FBGraphUser> *user, 
           NSError *error) {
             if (!error) {
                 self.userNameLabel.text = user.name;
                 self.userProfileImage.profileID = user.id;
              
                
             }
         }];      
    }
    
    
    
}
- (void)sessionStateChanged:(NSNotification*)notification
{
    [self loadUserProfile];
}

- (IBAction)logoutButtonWasPressed:(id)sender
{
    [FBSession.activeSession closeAndClearTokenInformation];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    //[super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
