//
//  OverlayViewController.m
//  engine
//
//  Created by sattia on 05/08/12.
//
//

#import "OverlayViewController.h"

@interface OverlayViewController ()

@end

@implementation OverlayViewController

+ (OverlayViewController *)sharedInstance;
{
    static OverlayViewController *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[OverlayViewController alloc] init];
    });
    return sharedInstance;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor clearColor];
    UIView *blackBackgroundView=[[UIView alloc]initWithFrame:CGRectMake(0,0,self.view.frame.size.width,self.view.frame.size.height)];
    blackBackgroundView.backgroundColor=[UIColor blackColor];
    blackBackgroundView.alpha=0.3;
    [self.view addSubview:blackBackgroundView];
    self.view.hidden=TRUE;
}


- (void)hideAndReset
{
    [[self.view subviews]makeObjectsPerformSelector:@selector(removeFromSuperview)];
    self.view.backgroundColor=[UIColor clearColor];
    UIView *blackBackgroundView=[[UIView alloc]initWithFrame:CGRectMake(0,0,self.view.frame.size.width,self.view.frame.size.height)];
    blackBackgroundView.backgroundColor=[UIColor blackColor];
    blackBackgroundView.alpha=0.3;
    [self.view addSubview:blackBackgroundView];
    self.view.hidden=TRUE;
}

- (void)dealloc
{
    //[super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
