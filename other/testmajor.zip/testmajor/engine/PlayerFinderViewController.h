//
//  PlayerFinderViewController.h
//  engine
//
//  Created by sattia on 05/08/12.
//
//

#import <UIKit/UIKit.h>
#import "PlayerFinderTableViewController.h"

@interface PlayerFinderViewController : UIViewController
{
    PlayerFinderTableViewController* tableViewController;
}

@property (strong, nonatomic) PlayerFinderTableViewController *tableViewController;

@end
