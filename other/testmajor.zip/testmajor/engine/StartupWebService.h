//
//  StartupWebService.h
//  engine
//
//  Created by sattia on 30/07/12.
//
//

#import <Foundation/Foundation.h>
#import "User.h"
#import <RestKit/RestKit.h>
#import <FacebookSDK/FacebookSDK.h>

#define STARTUP_STEP_0  0
#define STARTUP_STEP_1  1
#define STARTUP_STEP_2  2


@interface StartupWebService : NSObject
{
    NSMutableDictionary *startupData;
}


-(void)beginStartupSequenceWithCompletionHandler:(void (^)(NSDictionary* startupData))handler;

@property (retain) NSString* userId;
/*The current loading step during startup*/
@property (strong, nonatomic) NSNumber *startupStep;
/*Contains the data useful at startup when loaded, nil if not loaded*/
@property (strong, nonatomic) NSMutableDictionary *startupData;

/*Other useful data for the start of the application*/

@end
