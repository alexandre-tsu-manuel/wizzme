//
//  ChallengeFinderTableViewCell.h
//  engine
//
//  Created by sattia on 28/07/12.
//
//

#import <UIKit/UIKit.h>
#import "AsyncImageView.h"
#import "UserWebService.h"

@interface ChallengeFinderTableViewCell : UITableViewCell <UserWebServiceDelegate>


@property (strong, nonatomic) UIImageView *leftThumbnailImageView;
@property (strong, nonatomic) UILabel *titleLabel;
@property (strong, nonatomic) UILabel *subtitleLabel;
@property (strong, nonatomic) NSString *userId;

@end
