//
//  CustomTableViewController.h
//  engine
//
//  Created by sattia on 06/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "UserWebService.h"


@interface LoginTableViewController : UITableViewController <UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate,UserWebServiceDelegate>
{
    UIImageView* headerImageView;
}

@property (nonatomic, retain) NSDictionary *dataSource;
@property (nonatomic, retain) UIImageView *headerImageView;


@end
