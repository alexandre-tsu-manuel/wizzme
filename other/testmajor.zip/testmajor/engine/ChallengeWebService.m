//
//  ChallengeWebService.m
//  engine
//
//  Created by sattia on 16/09/12.
//
//

#import "ChallengeWebService.h"
#import <RestKit/RKJSONParserJSONKit.h>
#import "Macros.h"

#define CHALLENGES_FROM_USER_ID(id,poolId,minDate) [NSString stringWithFormat:@"/testmajor/_design/test/_rewrite/by-user?userId=%@&poolId=%@&minDate=%@",id,poolId,minDate]

#define CHALLENGE_REQUEST_TO_USER_ID(userId,poolId,comment) [NSString stringWithFormat:@"/testmajor/_design/test/_update/create?poolId=%@&challengersIds=%@&comment=%@",poolId,userId,comment]

@implementation ChallengeWebService

void (^_challengesFromUserIdCompletionHandler)(NSArray *receivedChallenges);
void (^_sendChallengeRequestToUserCompletionHandler)(NSDictionary *serverResponse);



- (void)challengesFromUserId:(NSString *)userId poolId:(NSString*)poolId minDate:(NSString*)minDate withCompletionHandler:(void (^)(NSArray *receivedChallenges))handler{
    
    _challengesFromUserIdCompletionHandler = [handler copy];
    
    NSString* urlString=CHALLENGES_FROM_USER_ID(userId,poolId,minDate);
    
    NSLog(@"URL STRING=%@",urlString);
    [[RKClient sharedClient] get:urlString delegate:self];
}
    

-(void)request:(RKRequest *)request didLoadResponse:(RKResponse *)response
{
    NSLog(@"Response=%@",[response bodyAsString]);
    RKJSONParserJSONKit *parser=[[RKJSONParserJSONKit alloc]init];
    NSDictionary *dict=[parser objectFromString:[response bodyAsString] error:nil];

    NSArray *challengesDictsArray=[dict objectForKey:@"tests"];
    NSMutableArray *challengesArray=[[NSMutableArray alloc]initWithCapacity:20];
    
    /*creating true "Challenge" objects instead of dicts*/
    for(int i=0;i<[challengesDictsArray count];i++){
        Challenge *c=[[Challenge alloc]init];
        if([[challengesDictsArray objectAtIndex:i] objectForKey:@"id"]){
            c.challengeId=[[challengesDictsArray objectAtIndex:i] objectForKey:@"id"];
        }
        if([[challengesDictsArray objectAtIndex:i] objectForKey:@"questionsIds"]){
            c.questionsIds=[[challengesDictsArray objectAtIndex:i] objectForKey:@"questionsIds"];
        }
        if([[challengesDictsArray objectAtIndex:i] objectForKey:@"userId"]){
            c.userId=[[challengesDictsArray objectAtIndex:i] objectForKey:@"userId"];
        }
        if([[challengesDictsArray objectAtIndex:i] objectForKey:@"date"]){
            c.date=[[challengesDictsArray objectAtIndex:i] objectForKey:@"date"];
        }
        if([[challengesDictsArray objectAtIndex:i] objectForKey:@"score"]){
            c.score=[[challengesDictsArray objectAtIndex:i] objectForKey:@"score"];
        }
        if([[challengesDictsArray objectAtIndex:i] objectForKey:@"winners"]){
            c.winners=[[challengesDictsArray objectAtIndex:i] objectForKey:@"winners"];
        }
    [challengesArray addObject:c];
    }
    
    //antoine, crash catch
    if ([challengesArray count])
        _challengesFromUserIdCompletionHandler(challengesArray);
    
}

-(void)sendChallengeRequestToUser:(NSString*)userId withGameStats:(NSDictionary*)gameStats withCompletionHandler:(void (^)(NSDictionary *serverResponse))handler{
    
    /*TODO : NEED TO MAKE THIS PART DYNAMIC, function of gameStats*/
    
    _sendChallengeRequestToUserCompletionHandler = [handler copy];
    NSString *urlString=CHALLENGE_REQUEST_TO_USER_ID(userId,@"questionpool-0",@"comment");
    NSLog(@"URL STRING=%@",urlString);
    
    NSMutableDictionary *q0=[[NSMutableDictionary alloc]initWithCapacity:5];
    [q0 setObject:@"question-0" forKey:@"id"];
    
    [q0 setObject:[NSArray arrayWithObjects:[NSNumber numberWithBool:false],[NSNumber numberWithBool:true],[NSNumber numberWithBool:true],[NSNumber numberWithBool:false],[NSNumber numberWithBool:false],nil] forKey:@"correctAnswer"];
    [q0 setObject:[NSArray arrayWithObjects:[NSNumber numberWithBool:false],[NSNumber numberWithBool:true],[NSNumber numberWithBool:false],[NSNumber numberWithBool:false],[NSNumber numberWithBool:true],nil] forKey:@"userAnswer"];
    
    [q0 setObject:[NSNumber numberWithFloat:0.3] forKey:@"score"];
    [q0 setObject:[NSNumber numberWithFloat:2.6] forKey:@"time"];
    
    NSMutableDictionary *q1=[[NSMutableDictionary alloc]initWithCapacity:5];
    [q1 setObject:@"question-0" forKey:@"id"];
    
    [q1 setObject:[NSArray arrayWithObjects:[NSNumber numberWithBool:false],[NSNumber numberWithBool:true],[NSNumber numberWithBool:true],[NSNumber numberWithBool:false],[NSNumber numberWithBool:false],nil] forKey:@"correctAnswer"];
    [q1 setObject:[NSArray arrayWithObjects:[NSNumber numberWithBool:false],[NSNumber numberWithBool:true],[NSNumber numberWithBool:false],[NSNumber numberWithBool:false],[NSNumber numberWithBool:true],nil] forKey:@"userAnswer"];
    
    [q1 setObject:[NSNumber numberWithFloat:0.3] forKey:@"score"];
    [q1 setObject:[NSNumber numberWithFloat:2.6] forKey:@"time"];

    NSArray *statsArray=[NSArray arrayWithObjects:q0,q1,nil];
    RKJSONParserJSONKit *parser=[[RKJSONParserJSONKit alloc]init];
    NSString *jsonString=[parser stringFromObject:statsArray error:nil];
    RKParams *params = [RKRequestSerialization serializationWithData:[jsonString dataUsingEncoding:NSASCIIStringEncoding]MIMEType:RKMIMETypeJSON];
    
    //NSLog(@"JSON String=%@",jsonString);

    
    [[RKClient sharedClient] put:urlString params:params delegate:self];
    
    
    
}

-(void)request:(RKRequest *)request didFailLoadWithError:(NSError *)error
{
    NSLog(@"ERROR in ChallengeWebService=%@",error);
}


- (void)objectLoader:(RKObjectLoader*)objectLoader didLoadObjects:(NSArray*)objects
{
  
}

- (void)objectLoader:(RKObjectLoader*)objectLoader didFailWithError:(NSError*)error
{

}
    
@end
