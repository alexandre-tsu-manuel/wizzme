//
//  AppDelegate.h
//  engine
//
//  Created by sattia on 06/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <RestKit/RestKit.h>
#import <RestKit/CoreData.h>
#import "StartupWebService.h"
#import "UserWebService.h"

extern NSString *const SCSessionStateChangedNotification;



@interface AppDelegate : UIResponder <UIApplicationDelegate,UINavigationControllerDelegate>
{
    //UINavigationController* navigationController;
}
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UINavigationController *navigationController;


- (void)openFacebookSession;
- (void)openEmailSession;


@end
