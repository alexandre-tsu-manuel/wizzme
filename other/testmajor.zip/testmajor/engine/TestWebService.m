//
//  ChallengeWebService.m
//  engine
//
//  Created by sattia on 16/09/12.
//
//

#import "TestWebService.h"
#import <RestKit/RKJSONParserJSONKit.h>

#define TESTS_FROM_CHALLENGE_ID(challengeId) [NSString stringWithFormat:@"/testmajor/_design/test/_rewrite/challenge/%@",challengeId]



@implementation TestWebService

void (^_testsFromChallengeIdCompletionHandler)(NSArray *receivedChallenges);


- (void)testsFromChallengeId:(NSString *)challengeId withCompletionHandler:(void (^)(NSArray *receivedTests))handler{
    
    _testsFromChallengeIdCompletionHandler = [handler copy];
    RKObjectMapping *testMapping=[Test objectMapping];
    [[RKObjectManager sharedManager].mappingProvider setMapping:testMapping forKeyPath:@"tests"];
    [[RKObjectManager sharedManager] loadObjectsAtResourcePath:TESTS_FROM_CHALLENGE_ID(challengeId) delegate:self];

}


- (void)objectLoader:(RKObjectLoader*)objectLoader didLoadObjects:(NSArray*)objects
{
    NSLog(@"OBJECTS RECEIVED=%@",objects);
    _testsFromChallengeIdCompletionHandler(objects);
    
}

- (void)objectLoader:(RKObjectLoader*)objectLoader didFailWithError:(NSError*)error
{
    
}

-(void)request:(RKRequest *)request didLoadResponse:(RKResponse *)response
{
    NSLog(@"Response=%@",[response bodyAsString]);
    RKJSONParserJSONKit *parser=[[RKJSONParserJSONKit alloc]init];
    NSDictionary * dict=[parser objectFromString:[response bodyAsString] error:nil];
    
    
    
}

-(void)request:(RKRequest *)request didFailLoadWithError:(NSError *)error
{
    NSLog(@"ERROR in UserWebService=%@",error);
}

@end
