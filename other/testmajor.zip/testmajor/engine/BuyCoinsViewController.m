//
//  BuyCoinsViewController.m
//  engine
//
//  Created by sattia on 09/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "BuyCoinsViewController.h"
#import "Macros.h"
@interface BuyCoinsViewController ()

@end

@implementation BuyCoinsViewController

@synthesize tableViewController=_tableViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIImageView* backgroundImageView = [[UIImageView alloc]initWithFrame:
                                        CGRectMake(0, 0, kScreenWidth, self.view.frame.size.height)];
    backgroundImageView.image=[UIImage imageNamed:@"background.png"];
    
    
    UIView* tableViewWrapper=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 600)];
    tableViewWrapper.backgroundColor=[UIColor clearColor];

    _tableViewController=[[BuyCoinsTableViewController alloc]initWithStyle:UITableViewStyleGrouped];
    
    
    [tableViewWrapper addSubview:_tableViewController.tableView];
    
    [self.view addSubview:backgroundImageView];
    [self.view addSubview:tableViewWrapper];
}

- (void)dealloc
{
    //[super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
