//
//  RKUser.h
//  engine
//
//  Created by sattia on 27/07/12.
//
//

#import <Foundation/Foundation.h>
#import <RestKit/RestKit.h>

@interface User : NSObject
{
    
    NSString* userId;
    NSString* facebookId;
    NSString* facebookLocationId;
    NSString* nickname;
    NSString* thirdPartyId;
    NSNumber* scoreTotal;
    NSNumber* nbCoins;
    NSArray* location;
}



@property (nonatomic, retain) NSString* nickname;
@property (nonatomic, retain) NSString* thirdPartyId;
@property (nonatomic, retain) NSString* userId;
@property (nonatomic, retain) NSArray* location;
@property (nonatomic, retain) NSNumber* nbCoins;
@property (nonatomic, retain) NSNumber* scoreTotal;
@property (nonatomic, retain) NSString* facebookLocationId;
@property (nonatomic, retain) NSString* facebookId;


+ (RKObjectMapping *)objectMapping;
+ (User *)userWithInfo:(NSDictionary*)userInfo;

@end
