//
//  CustomTableViewController.h
//  engine
//
//  Created by sattia on 06/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TestWebService.h"
#import <RestKit/RestKit.h>

@interface ChallengeFinderTableViewController : UITableViewController <UITableViewDelegate,UITableViewDataSource>

@property (retain, strong) NSMutableDictionary *dataSource;

-(void)reloadChallenges;
@end
