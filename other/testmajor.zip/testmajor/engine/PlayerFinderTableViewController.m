//
//  PlayerFinderTableViewController.m
//  engine
//
//  Created by sattia on 06/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "PlayerFinderTableViewController.h"
#import "Macros.h"
#import "AppDelegate.h"

#import "OverlayViewController.h"
#import "ChallengeViewController.h"
#import "TestWebService.h"
#import "ChallengeWebService.h"


#define TITLE_LABEL_TAG 0
#define SUBTITLE_LABEL_TAG 1
#define THUMBNAIL_TAG 2



@interface PlayerFinderTableViewController ()
@property (strong, nonatomic) FBFriendPickerViewController *friendPickerController;
@property (strong, nonatomic) TestWebService *testWebService;
@property (strong, nonatomic) ChallengeWebService *challengeWebService;
@property (strong, nonatomic) UserWebService *userWebService;

@end

@implementation PlayerFinderTableViewController

@synthesize dataSource=_dataSource;
@synthesize headerImageView=_headerImageView;
@synthesize friendPickerController = _friendPickerController;
@synthesize selectedFriends = _selectedFriends;
@synthesize testWebService=_testWebService;
@synthesize challengeWebService=_challengeWebService;
@synthesize userWebService=_userWebService;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        UIImageView* tableViewHeaderImageView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"header_login_tableView.png"]];
        _dataSource = [NSDictionary dictionaryWithObjectsAndKeys:
                       @"2",@"row_count",
                       @"facebook", TITLE_KEY_FROM_INDEXPATH(0), 
                       @"Trouver votre partenaire dans vos amis",SUBTITLE_KEY_FROM_INDEXPATH(0), 
                       @"Aléatoire",TITLE_KEY_FROM_INDEXPATH(1), 
                       @"Nous allons te trouver un partenaire de révision",SUBTITLE_KEY_FROM_INDEXPATH(1), 
                       @"facebook_thumbnail.png",THUMBNAILURL_KEY_FROM_INDEXPATH(0),
                       @"facebook_thumbnail.png",THUMBNAILURL_KEY_FROM_INDEXPATH(1),
                       tableViewHeaderImageView, @"header_background",nil];
        
    }
    return self;
}

- (void)viewDidLoad
{
    
    self.tableView.backgroundColor=[UIColor clearColor];
    //self.tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth;
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    _headerImageView=[_dataSource objectForKey:@"header_background"];
    [self.tableView reloadData];

    
    [super viewDidLoad];
    
}





- (void)dealloc
{
    self.friendPickerController = nil;
    //[super dealloc];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Number of rows is the number of time zones in the region for the specified section.
    return [[_dataSource objectForKey:ROW_COUNT] intValue]+1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
	if([indexPath row] == 0){
		return 47;
	}
    else {
        return 80;
    }
    
}




- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                      reuseIdentifier:CellIdentifier];
    }
    
    if(indexPath.row==0){
        cell.backgroundView=_headerImageView;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
    }
    else{
        
        
        UIImageView* leftThumbnailImageView=[[UIImageView alloc]initWithFrame:CGRectMake(10,10, 40, 40)];
        leftThumbnailImageView.image=[UIImage imageNamed:[_dataSource objectForKey:THUMBNAILURL_KEY_FROM_INDEXPATH(indexPath.row-1)]];
        leftThumbnailImageView.tag=THUMBNAIL_TAG;
        
        [cell.contentView addSubview:leftThumbnailImageView];
        
        UILabel *title, *subtitle;
        title = [[UILabel alloc] initWithFrame:CGRectMake(65, 10, 220, 15)];
        title.tag = TITLE_LABEL_TAG;
        title.font = [UIFont systemFontOfSize:17.0];
        title.text=[_dataSource objectForKey:TITLE_KEY_FROM_INDEXPATH(indexPath.row-1)];
        title.textAlignment = UITextAlignmentLeft;
        title.backgroundColor=[UIColor clearColor];
        
        subtitle = [[UILabel alloc] initWithFrame:CGRectMake(65, 30, 220, 15)];
        subtitle.tag = SUBTITLE_LABEL_TAG;
        subtitle.text=[_dataSource objectForKey:SUBTITLE_KEY_FROM_INDEXPATH(indexPath.row-1)];
        subtitle.font = [UIFont systemFontOfSize:10.4];
        subtitle.textColor = [UIColor darkGrayColor];
        subtitle.backgroundColor=[UIColor clearColor];
        subtitle.textAlignment = UITextAlignmentLeft;
        
        
        [cell.contentView addSubview:leftThumbnailImageView];
        [cell.contentView addSubview:title];
        [cell.contentView addSubview:subtitle];
        
        
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
    if(indexPath.row==1){
        if (!self.friendPickerController) {

            self.friendPickerController = [[FBFriendPickerViewController alloc] 
                                           initWithNibName:nil bundle:nil];
            
            // Set the friend picker delegate
            self.friendPickerController.delegate = self;
            
            //self.friendPickerController.title = @"Select friends";
        }
        
        [self.friendPickerController loadData];
        AppDelegate* appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
        [appDelegate.navigationController pushViewController:self.friendPickerController 
                                                    animated:true];
        
        [[OverlayViewController sharedInstance]hideAndReset];
        
    }
    if(indexPath.row==2){
        NSLog(@"FIND RANDOM PARTNER");
    }
    
}


- (void)startGame 
{
    int friendCount = self.selectedFriends.count;
    
    if(friendCount>0){
        
        
        id<FBGraphUser> gamePartner = [self.selectedFriends objectAtIndex:0];
        NSLog(@"Challenge Partner Name=%@", gamePartner.name);
        
        /*
        if(_challengeWebService==nil){
         _challengeWebService=[[ChallengeWebService alloc]init];
         }
        //629347342
        [_challengeWebService sendChallengeRequestToUser:@"pilipmalette@gmail.com" withGameStats:nil withCompletionHandler:^(NSDictionary *serverResponse) {
            NSLog(@"challengeRequest sent");
        }];
        */
        
        if(_challengeViewController==nil){
            _challengeViewController=[[ChallengeViewController alloc]initWithNibName:@"ChallengeViewController" bundle:nil];
        }
        
        [OverlayViewController sharedInstance].view.hidden=FALSE;
        [[OverlayViewController sharedInstance].view addSubview:_challengeViewController.view];
        
    }
    
    
}

- (void)friendPickerViewControllerSelectionDidChange:(FBFriendPickerViewController *)friendPicker
{
    self.selectedFriends = friendPicker.selection;
    [self startGame];
}




@end
