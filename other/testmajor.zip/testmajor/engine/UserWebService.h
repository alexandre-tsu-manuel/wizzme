//
//  ChallengeWebService.h
//  engine
//
//  Created by sattia on 28/07/12.
//
//

#import <Foundation/Foundation.h>
#import "User.h"
#import <RestKit/RestKit.h>
#import <RestKit/RKRequestSerialization.h>


@interface UserWebService : NSObject <RKObjectLoaderDelegate,RKRequestDelegate>
{
    //id delegate;
    
}
- (void)userFromUserId:(NSString *)userId;
- (void)userFromUserId:(NSString *)userId withCompletionHandler:(void (^)(User *receivedUser))handler;
- (void)createUserWithInfo:(NSDictionary *)userInfo withCompletionHandler:(void (^)(NSString* completionStatus))handler;


@property (assign, nonatomic) id delegate;

@end

@protocol UserWebServiceDelegate
@optional
- (void)userWebService:(UserWebService *)webService didReceiveUsers:(NSArray *)usersArray;
- (void)userWebService:(UserWebService *)webService didFailWithError:(NSError *)error;
- (void)userWebService:(UserWebService *)webService didCreateUserAccountWithResponse:(NSDictionary*)response;
@end
