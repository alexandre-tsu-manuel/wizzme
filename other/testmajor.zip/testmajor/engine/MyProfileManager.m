//
//  TMProfileManager.m
//  engine
//
//  Created by sattia on 16/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MyProfileManager.h"
#import "Macros.h"
#import "User.h"
@implementation MyProfileManager

@synthesize myProfile=_myProfile;
@synthesize userWebService=_userWebService;
@synthesize facebookThirdPartyId=_facebookThirdPartyId;

NSString *const UserProfileChangedNotification = @"UserProfileChangedNotification";

void (^_getMyProfileCompletionHandler)(User *userProfile);
void (^_facebookUserInfoCompletionHandler)(NSDictionary *facebookUserInfo);

+ (MyProfileManager *)sharedInstance;
{
    static MyProfileManager *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[MyProfileManager alloc] init];
    });
    return sharedInstance;
}

- (void)myFacebookUserInfoWithCompletionHandler:(void (^)(NSDictionary *facebookUserInfo))handler
{
    _facebookUserInfoCompletionHandler = [handler copy];
    
    if (FBSession.activeSession.isOpen) {
        NSString *accessToken=FBSession.activeSession.accessToken;
        NSLog(@"Access Token %@",accessToken);
        [[FBRequest requestForGraphPath:[NSString stringWithFormat:@"me?fields=id,third_party_id,name,location&access_token=%@",accessToken]] startWithCompletionHandler:
         ^(FBRequestConnection *connection,
           NSDictionary *user,
           NSError *error) {
             if (!error) {
                 _facebookUserInfoCompletionHandler(user);
                 
             }
         }];
    }
}

-(void)getMyProfileWithCompletionHandler:(void (^)(User *userProfile))handler{
    _getMyProfileCompletionHandler = [handler copy];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    if(_userWebService==nil){
        _userWebService=[[UserWebService alloc]init];
    }
    [_userWebService userFromUserId:[[defaults objectForKey:@"credentials"] objectForKey:@"username"] withCompletionHandler:^(User *receivedUser) {
        _myProfile=receivedUser;
        _getMyProfileCompletionHandler(receivedUser);
        [[NSNotificationCenter defaultCenter]
         postNotificationName:UserProfileChangedNotification
         object:receivedUser];
    }];
}

@end
