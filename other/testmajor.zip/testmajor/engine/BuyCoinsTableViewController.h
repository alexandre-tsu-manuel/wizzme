//
//  BuyCoinsTableViewController.h
//  engine
//
//  Created by sattia on 09/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BuyCoinsTableViewController : UITableViewController
{
    UIImageView* headerImageView;
}

@property (nonatomic, retain) NSDictionary *dataSource;
@property (nonatomic, retain) UIImageView *headerImageView;

@end
