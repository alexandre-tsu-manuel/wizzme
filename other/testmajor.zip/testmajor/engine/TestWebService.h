//
//  ChallengeWebService.h
//  engine
//
//  Created by sattia on 28/07/12.
//
//

#import <Foundation/Foundation.h>
#import "Challenge.h"
#import "Test.h"
#import <RestKit/RestKit.h>
#import <RestKit/RKRequestSerialization.h>


@interface TestWebService : NSObject <RKObjectLoaderDelegate,RKRequestDelegate>


-(void)testsFromChallengeId:(NSString *)challengeId withCompletionHandler:(void (^)(NSArray *receivedTests))handler;

@end



/*
@protocol ChallengeWebServiceDelegate
- (void)challengeWebService:(ChallengeWebService *)webService didReceiveChallenges:(NSArray *)challengesArray;
- (void)challengeWebService:(ChallengeWebService *)webService didFailWithError:(NSError *)error;
@end
*/
