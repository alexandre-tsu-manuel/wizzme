//
//  ChallengeViewController.m
//  engine
//
//  Created by Antoine Vigier on 20/10/12.
//
//

#import "ChallengeViewController.h"
#import "OverlayViewController.h"


@interface ChallengeViewController ()

@property (strong, nonatomic) DMPlayerViewController *playerViewController;
@property (strong, nonatomic) NSDictionary *_fieldsData;
@property (weak, nonatomic) IBOutlet UITableViewCell *challengeViewCell;

@end

@implementation ChallengeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Init the player
    self.playerViewController = [[DMPlayerViewController alloc] initWithParams:
                                 @{
                                 @"autoplay":@"1",//we auto start
                                 @"info":@"0",//no info (title/author)
                                 @"related":@"0",//no related video at the end
                                 @"logo":@"0",//we hide the dailymotion logo
                                 }];
    self.playerViewController.delegate = self;
    [self addChildViewController:self.playerViewController];
    self.playerViewController.view.frame = self.playerContainerView.bounds;
    [self.playerContainerView addSubview:self.playerViewController.view];
    
    [self configureView];
}

- (void)configureView
{
    // Update the user interface for the detail item.
    
    [self.playerViewController load:@"x1isrs"];
    
    /*
    if (self._fieldsData)
    {
        //self.title = self._fieldsData[@"title"];
        //self.titleLabel.text = self._fieldsData[@"title"];
        //self.descriptionTextView.text = self._fieldsData[@"description"];
        [self.playerViewController load:self._fieldsData[@"id"]];
    }
    else
    {
        //self.title = self._fieldsData[@"title"];
        //self.titleLabel.text = nil;
        //self.descriptionTextView.text = nil;
        [self.playerViewController pause];
    }
    */
}


#pragma mark actions

- (IBAction)closeButtonPressed:(id)sender
{
    [[OverlayViewController sharedInstance]hideAndReset];
}


#pragma mark UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil)
    {
        [[NSBundle mainBundle] loadNibNamed:@"ChallengeViewCell" owner:self options:nil];
        cell = self.challengeViewCell;
    }
    cell.textLabel.text = [NSString stringWithFormat:@"%d", indexPath.row + 1];
    return cell;
}


#pragma mark UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
}


#pragma mark DMPlayerDelegate

- (void)webViewDidStartLoad:(UIWebView *)webView
{
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
}

@end
