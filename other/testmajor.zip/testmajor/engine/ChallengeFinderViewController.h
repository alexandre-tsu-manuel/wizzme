//
//  LoginViewController.h
//  engine
//
//  Created by sattia on 06/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChallengeFinderTableViewController.h"
#import <FacebookSDK/FacebookSDK.h>
@interface ChallengeFinderViewController : UIViewController
{
    
    ChallengeFinderTableViewController* tableViewController;
}

@property (retain,strong) ChallengeFinderTableViewController *tableViewController;


- (void)reloadChallenges;

@end
