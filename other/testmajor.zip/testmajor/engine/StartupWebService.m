//
//  StartupWebService.m
//  engine
//
//  Created by sattia on 30/07/12.
//
//

#import "StartupWebService.h"
#import "User.h"
#import "Macros.h"
#import "MyProfileManager.h"
#import "UserWebService.h"

@interface StartupWebService()

-(void)startStep0;
-(void)startStep1;


@property (strong, nonatomic) User *myProfile;
@property (strong, nonatomic) UserWebService *userWebService;

@end


@implementation StartupWebService

@synthesize startupStep=_startupStep;
@synthesize myProfile=_myProfile;
@synthesize userWebService=_userWebService;
@synthesize startupData=_startupData;

void (^_startupCompletionHandler)(NSDictionary* startupData);

#define ME_STATIC_URL [NSString stringWithFormat:@"/me.json"]


/*Get user profile from our server*/
-(void)startStep0
{
    _startupStep=[NSNumber numberWithInt:STARTUP_STEP_0];
    
    if(_userWebService==nil){
        _userWebService=[[UserWebService alloc]init];
    }
    
    [_userWebService userFromUserId:ME_STATIC_URL withCompletionHandler:^(User *receivedUser) {
        _startupData=[[NSMutableDictionary alloc]initWithCapacity:2];
        [_startupData setObject:receivedUser forKey:@"my_profile"];
        [self startStep1];
    }];

}

/*Get user profile from facebook*/
-(void)startStep1{
    _startupStep=[NSNumber numberWithInt:STARTUP_STEP_1];
 
    /*If a facebook session is open...*/
    if (FBSession.activeSession.isOpen) {
        NSString *accessToken=FBSession.activeSession.accessToken;
        NSLog(@"Access Token %@",accessToken);
        [[FBRequest requestForGraphPath:[NSString stringWithFormat:@"me?fields=id,third_party_id,location&access_token=%@",accessToken]] startWithCompletionHandler:
         ^(FBRequestConnection *connection,
           NSDictionary *user,
           NSError *error) {
             if (!error) {
                 NSLog(@"user.third_party_id=%@",[user objectForKey:@"third_party_id"]);
                 NSLog(@"user.location=%@",[[user objectForKey:@"location"]objectForKey:@"name"]);
                 
                 [_startupData setObject:[user objectForKey:@"third_party_id"] forKey:@"third_party_id"];
                 [MyProfileManager sharedInstance].myProfile.userId=[user objectForKey:@"id"];
                 [MyProfileManager sharedInstance].myProfile.nickname=[user objectForKey:@"name"];
                 [MyProfileManager sharedInstance].myProfile.facebookLocationId=[[user objectForKey:@"location"]objectForKey:@"id"];
                  _startupCompletionHandler(_startupData);
             }
         }];
    }

    
   
}

-(void)beginStartupSequenceWithCompletionHandler:(void (^)(NSDictionary* startupData))handler {
    _startupCompletionHandler = [handler copy];
    [self startStep0];
  
}
@end
