//
//  PlayerFinderViewController.m
//  engine
//
//  Created by sattia on 05/08/12.
//
//

#import "PlayerFinderViewController.h"
#import "Macros.h"
#import "OverlayViewController.h"

@interface PlayerFinderViewController ()
-(IBAction)closeButtonPressed:(id)sender;
@end

@implementation PlayerFinderViewController

@synthesize tableViewController=_tableViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	/*UIImageView* backgroundImageView = [[UIImageView alloc]initWithFrame:
                                        CGRectMake(0, 0, kScreenWidth, self.view.frame.size.height)];
    backgroundImageView.image=[UIImage imageNamed:@"background.png"];*/

    self.view.backgroundColor=[UIColor clearColor];
    
    UIView* tableViewWrapper=[[UIView alloc]initWithFrame:CGRectMake(0.f, 0.f, 320.f, kScreenHeight)];
    
    
    UIButton *closeButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    closeButton.frame = CGRectMake(200.f, 20.f, 100.f, 44.f); // position in the parent view and set the size of the button
    [closeButton setTitle:@"Fermer" forState:UIControlStateNormal];
    [closeButton addTarget:self action:@selector(closeButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    
    _tableViewController=[[PlayerFinderTableViewController alloc]initWithStyle:UITableViewStyleGrouped];
    [_tableViewController.tableView setContentInset:UIEdgeInsetsMake(100.f, 0.f, 0.f, 0.f)];
    [_tableViewController.tableView.backgroundView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    [tableViewWrapper addSubview:_tableViewController.tableView];
    
    //[self.view addSubview:backgroundImageView];
    [self.view addSubview:tableViewWrapper];
    [self.view addSubview:closeButton];

}

-(IBAction)closeButtonPressed:(id)sender
{
    [[OverlayViewController sharedInstance]hideAndReset];
}

- (void)dealloc
{
    //[super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
