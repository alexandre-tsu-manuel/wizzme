//
//  ChallengeWebService.h
//  engine
//
//  Created by sattia on 16/09/12.
//
//

#import <Foundation/Foundation.h>
#import "Challenge.h"
#import <RestKit/RestKit.h>
#import <RestKit/RKRequestSerialization.h>

@interface ChallengeWebService : NSObject <RKObjectLoaderDelegate,RKRequestDelegate>
{
    //id delegate;
    
}
- (void)challengesFromUserId:(NSString *)userId poolId:(NSString*)poolId minDate:(NSString*)minDate withCompletionHandler:(void (^)(NSArray *receivedChallenges))handler;

-(void)sendChallengeRequestToUser:(NSString*)userId withGameStats:(NSDictionary*)gameStats withCompletionHandler:(void (^)(NSDictionary *serverResponse))handler;

@property (assign, nonatomic) id delegate;



@end
