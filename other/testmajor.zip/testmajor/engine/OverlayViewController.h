//
//  OverlayViewController.h
//  engine
//
//  Created by sattia on 05/08/12.
//
//

#import <UIKit/UIKit.h>

@interface OverlayViewController : UIViewController


+ (OverlayViewController *)sharedInstance;

/*Use this method to clean the view hierarchy when the OverlayViewController has been used
 and you want to reuse it*/
- (void)hideAndReset;
@end
