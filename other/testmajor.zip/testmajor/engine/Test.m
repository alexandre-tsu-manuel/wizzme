//
//  Test.m
//  engine
//
//  Created by sattia on 19/08/12.
//
//

#import "Test.h"

@implementation Test


@synthesize testId;
@synthesize type;
@synthesize context;
@synthesize poolId;
@synthesize userId;
@synthesize challengersIds;
@synthesize date;
@synthesize questions;
@synthesize nbrCoins;
@synthesize comment;


+ (RKObjectMapping *)objectMapping
{
    RKObjectMapping *mapping = [RKObjectMapping mappingForClass:[self class]];
    [mapping mapKeyPath:@"_id" toAttribute:@"testId"];
    [mapping mapKeyPath:@"type" toAttribute:@"type"];
    [mapping mapKeyPath:@"context" toAttribute:@"context"];
    [mapping mapKeyPath:@"poolId" toAttribute:@"poolId"];
    [mapping mapKeyPath:@"userId" toAttribute:@"userId"];
    [mapping mapKeyPath:@"challengersIds" toAttribute:@"challengersIds"];
    [mapping mapKeyPath:@"date" toAttribute:@"date"];
    [mapping mapKeyPath:@"questions" toAttribute:@"questions"];
    [mapping mapKeyPath:@"nbrCoins" toAttribute:@"nbrCoins"];
    [mapping mapKeyPath:@"comment" toAttribute:@"comment"];
    mapping.setNilForMissingRelationships = YES;
    
    return mapping;
}

@end
