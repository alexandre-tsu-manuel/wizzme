//
//  AccountCreatorViewController.m
//  engine
//
//  Created by sattia on 11/08/12.
//
//

#import "AccountCreatorViewController.h"
#import "AccountCreatorView.h"

@interface AccountCreatorViewController ()

-(BOOL)NSStringIsValidEmail:(NSString *)checkString;
@property (strong, nonatomic) UserWebService *userWebService;


@end


@implementation AccountCreatorViewController

@synthesize userWebService=_userWebService;




- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (void)viewDidLoad
{
    
    [super viewDidLoad];
	self.view.backgroundColor=[UIColor grayColor];
    AccountCreatorView *accountCreatorView=[[AccountCreatorView alloc]initWithFrame:self.view.frame];
    [accountCreatorView setDelegate:self];
    
    self.view=accountCreatorView;
    /*_usernameTextField = [[UITextField alloc] initWithFrame:CGRectMake(20, 45.0, 260.0, 25.0)];
    _emailTextField = [[UITextField alloc] initWithFrame:CGRectMake(20, 85.0, 260.0, 25.0)];
    _passwordTextField = [[UITextField alloc] initWithFrame:CGRectMake(20, 125.0, 260.0, 25.0)];
 
    _emailTextField.backgroundColor=[UIColor whiteColor];
    _passwordTextField.backgroundColor=[UIColor whiteColor];
    _usernameTextField.backgroundColor=[UIColor whiteColor];
    
    _usernameTextField.text=@"Votre nom";
    _emailTextField.text=@"Votre email";
    _passwordTextField.text=@"Votre mot de passe";
    
    UIButton *okButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    okButton.frame = CGRectMake(200, 200, 100, 22);
    [okButton setTitle:@"Valider" forState:UIControlStateNormal];
    [okButton addTarget:self action:@selector(okButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:okButton];
    
    UIButton *cancelButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    cancelButton.frame = CGRectMake(100, 200, 100, 22);
    [cancelButton setTitle:@"Annuler" forState:UIControlStateNormal];
    [cancelButton addTarget:self action:@selector(cancelButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:cancelButton];
    
    
    [self.view addSubview:_emailTextField];
    [self.view addSubview:_passwordTextField];
    [self.view addSubview:_usernameTextField];*/
}

-(BOOL)NSStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSString *laxString = @".+@.+\\.[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

- (IBAction)accountCreatorViewOkButtonWasPressed:(id)sender
{
    AccountCreatorView *accountCreatorView=(AccountCreatorView*)self.view;
    
    /*Test fields validity and create a new user account in DB*/
    BOOL isValidEmail=[self NSStringIsValidEmail:accountCreatorView.emailTextField.text];
    if(isValidEmail==TRUE && ![accountCreatorView.passwordTextField.text isEqualToString:@""] && ![accountCreatorView.usernameTextField.text isEqualToString:@""]){
        if(_userWebService==nil){
            _userWebService=[[UserWebService alloc]init];
            [_userWebService setDelegate:self];
            NSMutableDictionary* userInfo = [[NSMutableDictionary alloc] init];
            [userInfo setObject:accountCreatorView.usernameTextField.text forKey:@"nickname"];
            [userInfo setObject:accountCreatorView.passwordTextField.text forKey:@"password"];
            [userInfo setObject:accountCreatorView.emailTextField.text forKey:@"email"];
            //[userInfo setObject:@"NA" forKey:@"facebookId"];
            //[userInfo setObject:@"NA" forKey:@"country"];
            //[userInfo setObject:@"NA" forKey:@"city"];
            [_userWebService createUserWithInfo:userInfo withCompletionHandler:^(NSString *completionStatus) {
                NSLog(@"AccountCreatorViewCotnroller: COMPLETION");
            }];
        }
    }else{
        
        if(isValidEmail==FALSE){
            NSLog(@"Votre email est invalide");
        }
        NSLog(@"Veuillez-rentrer les informations correctement");
    }
    
}


- (IBAction)accountCreatorViewCancelButtonWasPressed:(id)sender
{
    [self dismissViewControllerAnimated:TRUE completion:^{
        
    }];
}


- (void)dealloc
{
    //[super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
